N = int(input("Введите N: "))

if N % 2 == 0 and 10 <= N <= 99:
  print(True)
else:
  print(False)